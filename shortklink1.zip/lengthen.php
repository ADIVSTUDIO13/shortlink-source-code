<?php
header('Content-Type: application/json');
header('Strict-Transport-Security: max-age=63072000; includeSubDomains; preload');
header('Content-Security-Policy: default-src \'self\'');
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('X-XSS-Protection: 1; mode=block');

// Function to validate URL
function validateURL($url) {
    return filter_var($url, FILTER_VALIDATE_URL) !== false;
}

// Get ID from GET request
$id = isset($_GET['id']) ? $_GET['id'] : '';

if (empty($id)) {
    echo json_encode(array('success' => false, 'message' => 'ID is required.'));
    exit;
}

// Securely open and read the JSON file
$file = '../shortlinks.json';  // Path to the file outside the public directory
if (!file_exists($file)) {
    echo json_encode(array('success' => false, 'message' => 'Short links data not found.'));
    exit;
}

$shortLinkData = json_decode(file_get_contents($file), true);

if (!isset($shortLinkData[$id])) {
    echo json_encode(array('success' => false, 'message' => 'Short URL not found.'));
    exit;
}

// Return original URL
$originalURL = $shortLinkData[$id]['original_url'];
echo json_encode(array('success' => true, 'original_url' => $originalURL));
?>