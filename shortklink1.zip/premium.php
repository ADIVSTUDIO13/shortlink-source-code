<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Premium Member Area</title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .custom-bg {
            background: linear-gradient(to right, #667eea, #764ba2);
        }
        .premium-content {
            max-width: 600px;
            margin: auto;
            padding: 20px;
            background: #fff;
            border: 1px solid #ddd;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            margin-top: 50px;
        }
        .premium-title {
            font-size: 24px;
            font-weight: bold;
            margin-bottom: 20px;
            text-align: center;
            color: #333;
        }
        .premium-text {
            font-size: 16px;
            line-height: 1.6;
            color: #555;
        }
    </style>
</head>
<body class="custom-bg">
    <div class="premium-content">
        <h1 class="premium-title">Welcome to Premium Member Area</h1>
        <div class="premium-text">
            <p>Thank you for upgrading to our premium service!</p>
            <p>You now have access to additional features:</p>
            <ul>
                <li>Advanced link generation options</li>
                <li>Enhanced analytics</li>
                <li>Priority support</li>
            </ul>
            <p>Enjoy your premium experience!</p>
        </div>
    </div>
</body>
</html>
