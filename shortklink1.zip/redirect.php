<?php
header('Strict-Transport-Security: max-age=63072000; includeSubDomains; preload');
header('Content-Security-Policy: default-src \'self\'');
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('X-XSS-Protection: 1; mode=block');

// Get the short ID from the query parameter
$shortID = isset($_GET['id']) ? htmlspecialchars($_GET['id']) : '';

if (empty($shortID)) {
    echo 'No URL specified.';
    exit;
}

// Securely open and read the JSON file
$file = '../shortlinks.json';  // Path to the file outside the public directory
if (!file_exists($file)) {
    echo 'URL not found.';
    exit;
}
$shortLinkData = json_decode(file_get_contents($file), true);

if (isset($shortLinkData[$shortID]['original_url'])) {
    // Redirect to the original URL
    $originalURL = $shortLinkData[$shortID]['original_url'];
    header('Location: ' . $originalURL);
    exit;
} else {
    echo 'URL not found.';
    exit;
}
?>
