<?php
header('Content-Type: application/json');
header('Strict-Transport-Security: max-age=63072000; includeSubDomains; preload');
header('Content-Security-Policy: default-src \'self\'');
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('X-XSS-Protection: 1; mode=block');
// Function to generate a random ID
function generateRandomID($length = 6) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, strlen($characters) - 1)];
    }
    return $randomString;
}

// Validate URL
function validateURL($url) {
    return filter_var($url, FILTER_VALIDATE_URL) !== false;
}

// Sanitize URL
function sanitizeURL($url) {
    return filter_var($url, FILTER_SANITIZE_URL);
}

// Get URL from POST request
$data = json_decode(file_get_contents('php://input'), true);
$url = isset($data['url']) ? sanitizeURL($data['url']) : '';

if (empty($url)) {
    echo json_encode(array('success' => false, 'message' => 'URL is required.'));
    exit;
}

if (!validateURL($url)) {
    echo json_encode(array('success' => false, 'message' => 'Invalid URL.'));
    exit;
}

// Generate a unique short ID
$shortID = generateRandomID();

// Securely open and write to the JSON file
$file = '../shortlinks.json';  // Path to the file outside the public directory
if (!file_exists($file)) {
    file_put_contents($file, json_encode([]));
}
$shortLinkData = json_decode(file_get_contents($file), true);
$shortLinkData[$shortID] = array('original_url' => $url);

// Write data to the file
if (file_put_contents($file, json_encode($shortLinkData, JSON_PRETTY_PRINT)) === false) {
    echo json_encode(array('success' => false, 'message' => 'Failed to save the URL.'));
    exit;
}

// Return short URL
$shortURL = 'https://shortlink.aryastore.asia/redirect.php?id=' . $shortID;
echo json_encode(array('success' => true, 'link' => $shortURL));
?>