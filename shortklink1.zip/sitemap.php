<?php
// File sitemap.php

// Fungsi untuk menghasilkan URL dari database atau sumber lain
function generateUrls() {
    // Contoh daftar URL yang dihasilkan dinamis, Anda bisa sesuaikan dengan cara Anda sendiri
    $urls = array(
        "https://example.com/url1",
        "https://example.com/url2",
        "https://example.com/url3"
    );

    // Misalnya, Anda ingin menambahkan URL yang dihasilkan dari database atau tempat penyimpanan lainnya
    // $urls = array_merge($urls, fetchUrlsFromDatabase());

    return $urls;
}

// Fungsi untuk membuat sitemap.xml
function createSitemap() {
    // Panggil fungsi generateUrls() untuk mendapatkan daftar URL
    $urls = generateUrls();

    // Mulai pembuatan sitemap.xml
    $xml = '<?xml version="1.0" encoding="UTF-8"?>';
    $xml .= '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">';

    // Loop untuk menambahkan setiap URL ke sitemap.xml
    foreach ($urls as $url) {
        $xml .= '<url>';
        $xml .= '<loc>' . htmlspecialchars($url) . '</loc>';
        $xml .= '<lastmod>' . date("c", time()) . '</lastmod>'; // Tanggal terakhir modifikasi
        $xml .= '</url>';
    }

    $xml .= '</urlset>';

    // Simpan ke file sitemap.xml di direktori yang sama
    file_put_contents('sitemap.xml', $xml);
}

// Panggil fungsi createSitemap() untuk membuat sitemap saat file sitemap.php diakses
createSitemap();

// Beri respons ke mesin pencari bahwa sitemap.xml telah diperbarui
header("Content-Type: text/plain");
echo "Sitemap updated successfully.";
?>